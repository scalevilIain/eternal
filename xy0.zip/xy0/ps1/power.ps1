#Requires -RunAsAdministrator

param (
    [switch]$Silent
)


if (!$Silent) {
    $isLaptop = (Get-CimInstance -Class Win32_ComputerSystem -Property PCSystemType).PCSystemType -eq 2
    if ($isLaptop) {
        Write-Host @"
WARNING: You are on a laptop, disabling power saving will cause faster battery drainage and increased heat output.
        If you use your laptop on battery, certain power saving features will enable, but not all.
        Generally, it's NOT recommended to run this script on laptops.`n
"@ -ForegroundColor Yellow
        Start-Sleep 2
    }

    Write-Host @"
This script will disable many power saving features in Windows for reduced latency and increased performance.
Ensure that you have adequate cooling.`n
"@ -ForegroundColor Cyan
    #Pause
}

Write-Host "Disabling power-saving ACPI devices..." -ForegroundColor Yellow
& "C:\xy0\cmd\toggleDev.cmd" -Disable '@("ACPI Processor Aggregator", "Microsoft Windows Management Interface for ACPI")' | Out-Null

Write-Host "Disabling network adapter power-saving..." -ForegroundColor Yellow
$properties = Get-NetAdapter -Physical | Get-NetAdapterAdvancedProperty
foreach ($setting in @(
    # Stands for Ultra Low Power
    "ULPMode",

    # Energy Efficient Ethernet
    "EEE",
    "EEELinkAdvertisement",
    "AdvancedEEE",
    "EnableGreenEthernet",
    "EeePhyEnable",

    # Wi-Fi capability that saves power consumption
    "uAPSDSupport",

    # Self-explanatory
    "EnablePowerManagement",
    "EnableSavePowerNow",
    "bLowPowerEnable",
    "PowerSaveMode",
    "PowerSavingMode",
    "SavePowerNowEnabled",
    "AutoPowerSaveModeEnabled",
    "NicAutoPowerSaver",
    "SelectiveSuspend"
)) {
    $properties | Where-Object { $_.RegistryKeyword -eq "*$setting" -or $_.RegistryKeyword -eq $setting } | Set-NetAdapterAdvancedProperty -RegistryValue 0
}

Write-Host "Disabling device power-saving..." -ForegroundColor Yellow
$keys = Get-ChildItem -Path "HKLM:\SYSTEM\CurrentControlSet\Enum" -Recurse -EA 0
foreach ($value in @(
    "AllowIdleIrpInD3",
    "D3ColdSupported",
    "DeviceSelectiveSuspended",
    "EnableIdlePowerManagement",
    "EnableSelectiveSuspend",
    "EnhancedPowerManagementEnabled",
    "IdleInWorkingState",
    "SelectiveSuspendEnabled",
    "SelectiveSuspendOn",
    "WaitWakeEnabled",
    "WakeEnabled",
    "WdfDirectedPowerTransitionEnable"
)) {
    $keys | Where-Object { $_.GetValueNames() -contains $value } | ForEach-Object {
        $keyPath = $_.PSPath
        $oldValue = "$value-OLD"
        
        if ($null -eq (Get-ItemProperty -Path $keyPath -Name $oldValue -EA 0)) {
            Rename-ItemProperty -Path $keyPath -Name $value -NewName $oldValue -Force
        }

        Set-ItemProperty -Path $KeyPath -Name $value -Value 0 -Type DWORD -Force
    }
}
Get-CimInstance -ClassName MSPower_DeviceEnable -Namespace root/WMI | Set-CimInstance -Property @{ Enable = $false }

Write-Host "Disabling miscellaneous power-saving..." -ForegroundColor Yellow
# Disable D3 support on SATA/NVMEs while using Modern Standby
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Storage" -Name "StorageD3InModernStandby" -Value 0 -PropertyType DWORD -Force | Out-Null
# Disable IdlePowerMode for stornvme.sys (storage devices) - the device will never enter a low-power state
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Services\stornvme\Parameters\Device" -Name "IdlePowerMode" -Value 0 -PropertyType DWORD -Force | Out-Null
# Disable power throttling
$powerKey = "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling"
if (!(Test-Path $powerKey)) { New-Item $powerKey | Out-Null }
New-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Power\PowerThrottling" -Name "PowerThrottlingOff" -Value 1 -PropertyType DWORD -Force | Out-Null

#if ($Silent) { exit }
#Read-Pause "`nCompleted.`nPress Enter to exit"

exit