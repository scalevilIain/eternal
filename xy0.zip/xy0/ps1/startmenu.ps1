# Function to get all user profile registry paths (SIDs) from HKEY_USERS
# This replaces the custom Get-RegUserPaths function.
function Get-StandardUserPaths {
    # Get all SIDs under HKEY_USERS, excluding system/service accounts and templates
    # The paths are in the format Microsoft.PowerShell.Core\Registry::HKEY_USERS\<SID>
    $userSIDs = Get-ChildItem -Path 'Registry::HKEY_USERS' |
        Where-Object {
            $_.PSChildName -notmatch '^S-1-5-(18|19|20)$' -and # Exclude SYSTEM, LOCAL SERVICE, NETWORK SERVICE
            $_.PSChildName -notmatch 'Classes$' -and # Exclude Classes
            $_.PSChildName -notmatch 'Default$' # Exclude .DEFAULT (which is the template, not the actual default user hive)
        } |
        Select-Object -ExpandProperty PSPath

    # Add the .DEFAULT hive path for the default user profile template
    # This is equivalent to what AME might refer to as the "Default" user.
    $defaultHivePath = "Microsoft.PowerShell.Core\Registry::HKEY_USERS\.DEFAULT"

    # The original script seems to handle a separate "Default" state, which I will map to the .DEFAULT hive.
    # I'll create a custom object to hold the paths, similar to how the original script might have worked.
    $paths = @()
    foreach ($sid in $userSIDs) {
        $paths += [PSCustomObject]@{
            PSPath = $sid
            IsDefault = $false
        }
    }
    # Add the default user hive, which will be checked for the default logic
    $paths += [PSCustomObject]@{
        PSPath = $defaultHivePath
        IsDefault = $true
    }

    return $paths
}

# Function to get the Local AppData path for the .DEFAULT user profile.
# The original script used a custom function with a GUID for the default user.
# For the .DEFAULT hive, the Local AppData path is typically not directly accessible via Shell Folders
# in the same way as a loaded user hive. However, for configuring the default profile,
# we need to target the default user's AppData structure on the disk.
# The actual path for the default user's profile is usually C:\Users\Default\AppData\Local
function Get-DefaultUserLocalAppdataPath {
    # This is the standard location for the Local AppData folder of the Default user profile.
    $defaultUserPath = "$env:SystemDrive\Users\Default"
    if (Test-Path $defaultUserPath) {
        return Join-Path -Path $defaultUserPath -ChildPath "AppData\Local"
    } else {
        return $null
    }
}

# --- Start of the main script logic ---

# Replace Write-Title with standard Write-Host
function Write-Title {
    param([string]$Message)
    Write-Host "`n--- $Message ---" -ForegroundColor Cyan
}

# The original script's main loop:
foreach ($userPathObject in (Get-StandardUserPaths)) {
    $userKey = $userPathObject.PSPath
    $default = $userPathObject.IsDefault # Use the custom property to determine if it's the default hive
    $sid = Split-Path $userKey -Leaf

    # Get Local AppData path
    $appData = $null
    if ($default) {
        # This replaces: Get-UserPath -Folder 'F1B32785-6FBA-4FCF-9D55-7B8E7F157091'
        # We use the function to get the disk path for the Default user's AppData\Local
        $appData = Get-DefaultUserLocalAppdataPath
    } else {
        # Get the Local AppData path from the user's registry hive
        $shellFoldersPath = "$userKey\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders"
        try {
            $appData = (Get-ItemProperty -Path $shellFoldersPath -Name 'Local AppData' -ErrorAction Stop).'Local AppData'
        } catch {
            # This user hive might be a template or not fully configured, skip if it fails.
            # The original script used -EA 0 (SilentlyContinue) but I'll use a try/catch for clarity.
            Write-Error "Could not read 'Local AppData' for SID $sid. Skipping."
            continue
        }
    }

    Write-Title "Configuring Start Menu for '$sid'..."
    if ([string]::IsNullOrEmpty($appData) -or !(Test-Path $appData)) {
        Write-Error "Couldn't find or access AppData value for $sid! Path: '$appData'"
    } else {
        Write-Output "Copying default layout XML to '$appData\Microsoft\Windows\Shell\LayoutModification.xml'"
        
        # NOTE: The script requires a "Layout.xml" file to exist in the same directory as the script.
        # Ensure 'Layout.xml' is present before running.
        $layoutXmlPath = Join-Path -Path $PSScriptRoot -ChildPath "Layout.xml"
        if (Test-Path $layoutXmlPath) {
            Copy-Item -Path $layoutXmlPath -Destination "$appData\Microsoft\Windows\Shell\LayoutModification.xml" -Force
        } else {
            Write-Error "Layout.xml not found in the script directory. Skipping layout configuration for $sid."
        }
        
        if (!$default) {
            Write-Output "Clearing Start Menu pinned items"

            # The original script used $appdata\Packages, which is correct for a loaded user.
            $packagesPath = Join-Path -Path $appData -ChildPath "Packages"
            if (Test-Path $packagesPath) {
                $packages = Get-ChildItem -Path $packagesPath -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match "Microsoft.Windows.StartMenuExperienceHost" }
                foreach ($package in $packages) {
                    $binsPath = Join-Path -Path $packagesPath -ChildPath "$($package.Name)\LocalState"
                    if (Test-Path $binsPath) {
                        $bins = Get-ChildItem -Path $binsPath -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -like "start*.bin" }
                        foreach ($bin in $bins.FullName) {
                            Remove-Item -Path $bin -Force -ErrorAction SilentlyContinue
                        }
                    }
                }
            } else {
                Write-Output "Packages directory not found at $packagesPath. Skipping pinned items clear."
            }
        }
    }
    
    if (!$default) {
        Write-Output "Clearing default 'tilegrid' registry keys"
        # The path is relative to the user's hive ($userKey)
        $cloudStorePath = "$userKey\SOFTWARE\Microsoft\Windows\CurrentVersion\CloudStore\Store\Cache\DefaultAccount"
        
        if (Test-Path $cloudStorePath) {
            $tilegridKeys = Get-ChildItem -Path $cloudStorePath -Recurse -ErrorAction SilentlyContinue | Where-Object { $_.PSChildName -match "start.tilegrid" }    
            foreach ($key in $tilegridKeys) {
                # Remove-Item on a registry path will remove the key itself
                Remove-Item -Path $key.PSPath -Force -ErrorAction SilentlyContinue
            }
        } else {
            Write-Output "CloudStore path not found at $cloudStorePath. Skipping tilegrid clear."
        }
    }

    Write-Output "Removing advertisements/stubs from Start Menu (23H2+)"
    # This is a standard registry key, no change needed.
    Remove-ItemProperty -Path "$userKey\SOFTWARE\Microsoft\Windows\CurrentVersion\Start" -Name 'Config' -Force -ErrorAction SilentlyContinue
}
