# --------------------------------------------------------------
# Remove ads from the 'Accounts' page in Immersive Control Panel
# --------------------------------------------------------------

# Variables
$windir = [Environment]::GetFolderPath('Windows')
$viveToolPath = "C:\xy0\rsc\vive\ViVeTool.exe"
$settingsPagesCmd = "C:\xy0\cmd\settingsPages.cmd"

# Verify required files exist
if (!(Test-Path $viveToolPath)) {
    throw "ViVeTool not found at $viveToolPath!"
}
if (!(Test-Path $settingsPagesCmd)) {
    throw "settingsPages.cmd not found at $settingsPagesCmd!"
}

# Find the settings extensions JSON files
$settingsExtensions = (Get-ChildItem "$windir\SystemApps" -Recurse -ErrorAction SilentlyContinue).FullName | Where-Object { $_ -like '*wsxpacks\Account\SettingsExtensions.json*' }

$arm = ((Get-CimInstance -Class Win32_ComputerSystem).SystemType -match 'ARM64') -or ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64')

if ($settingsExtensions.Count -eq 0) {
    Write-Output "Settings extensions not found."
    Write-Output "User is likely on Windows 10, nothing to do. Exiting..."
    exit
}

# Function to recursively find velocity IDs
function Find-VelocityID($Node) {
    $ids = @()
    if ($Node -is [PSCustomObject]) {
        foreach ($property in $Node.PSObject.Properties) {
            if ($property.Name -eq 'velocityKey' -and $property.Value.id) {
                $ids += $property.Value.id
            }
            $ids += Find-VelocityID -Node $property.Value
        }
    } elseif ($Node -is [Array]) {
        foreach ($element in $Node) {
            $ids += Find-VelocityID -Node $element
        }
    }
    return $ids
}

# Gather velocity IDs
$ids = @()
foreach ($settingsJson in $settingsExtensions) {
    $content = Get-Content -Path $settingsJson -Raw | ConvertFrom-Json
    $ids += Find-VelocityID -Node $content
}

# Check for IDs
if ($ids.Count -le 0) {
    Write-Output "No velocity IDs were found. Exiting."
    exit 1
}

# Hide the 'Microsoft account' page in Settings
& $settingsPagesCmd /hide account

# Disable feature IDs
# Applies after next reboot
foreach ($id in ($ids | Sort-Object -Unique)) {
    Write-Output "Disabling feature ID $id..."
    & $viveToolPath /disable /id:$id | Out-Null
}

Write-Output "All feature IDs disabled. Please reboot to apply changes."
